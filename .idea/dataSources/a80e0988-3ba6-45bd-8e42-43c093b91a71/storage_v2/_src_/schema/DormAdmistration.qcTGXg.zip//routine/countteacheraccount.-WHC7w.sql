create
    definer = db2019@`%` procedure countteacheraccount()
begin
select count(*)from account where type="teacher";
end;

