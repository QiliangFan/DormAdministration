create
    definer = db2019@`%` procedure countmaxstuaccount()
begin
select sum(max_capacity) from room;
end;

