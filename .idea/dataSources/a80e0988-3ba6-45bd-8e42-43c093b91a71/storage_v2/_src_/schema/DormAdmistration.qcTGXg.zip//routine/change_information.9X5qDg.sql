create
    definer = db2019@`%` procedure change_information(IN s_id int, IN myname varchar(45), IN d_name varchar(45),
                                                      IN gra varchar(45), IN par_phone varchar(45),
                                                      IN myphone varchar(45), IN mygender varchar(45),
                                                      IN b_id varchar(45), IN ad_date varchar(45),
                                                      IN mybirthday varchar(45))
begin
declare flag int(10) default -1;
declare i_id varchar(45) default null;
select information_id into s_id from student where stu_id=s_id;
if(select*from student where stu_id=s_id) then
set flag=1;#已经存在 直接覆盖
else
set flag=0;#没存在 插入
end if;
if flag=1 then
update student set bed_id=b_id,dept_name=d_name,grade=gra,admission_date=ad_date,parent_phone=par_phone where stu_id=s_id;
update information set name=myname,own_phone=myphone,gender=mygender,birthday=mybirthday where information_id=i_id;
else
insert into student (bed_id,dept_name,grade,admission_date,parent_phone)values(b_id,d_name,gra,ad_date,par_phone);
insert into informtion (name,own_phone,gender,birthdayy)values(myname,myphone,mygender,mybirthday);
end  if;
end;

