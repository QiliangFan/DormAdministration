create
    definer = db2019@`%` procedure findpeople(IN p_name varchar(45), IN s_id varchar(45))
begin
declare b_id varchar(45) default null;
select room_build_id into b_id from student where stu_id=s_id;
select B.name,A.stu_id,A.dept_name,A.grade,A.room_id from
(select * from information where name=p_name)as B natural join
(select * from student where information_id in (select information_id from B))as A;
end;

