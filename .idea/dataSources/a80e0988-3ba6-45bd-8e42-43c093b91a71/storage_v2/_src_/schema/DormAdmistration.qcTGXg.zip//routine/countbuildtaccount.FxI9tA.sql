create
    definer = db2019@`%` procedure countbuildtaccount()
begin
select count(*)from building;
end;

