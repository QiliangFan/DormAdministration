create
    definer = db2019@`%` procedure countroomaccount()
begin
select count(*)from room;
end;

