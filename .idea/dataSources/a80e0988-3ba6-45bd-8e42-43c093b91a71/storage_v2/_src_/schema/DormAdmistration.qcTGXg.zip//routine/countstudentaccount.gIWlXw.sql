create
    definer = db2019@`%` procedure countstudentaccount()
begin
select count(*)from account where type="student";
end;

