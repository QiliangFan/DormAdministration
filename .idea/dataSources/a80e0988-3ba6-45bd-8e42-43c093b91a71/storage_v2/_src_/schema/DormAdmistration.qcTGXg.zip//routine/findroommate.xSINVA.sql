create
    definer = db2019@`%` procedure findroommate(IN s_id varchar(45))
begin
DECLARE r_id varchar(45) default null;
DECLARE b_id varchar(45) default null;
select room_id,room_build_id into r_id,b_id from student where stu_id=s_id;
create table roommate (
  `stu_id` INT NOT NULL,
  `bed_id` VARCHAR(45) NULL,
  `dept_name` VARCHAR(45) NULL,
  `grade` VARCHAR(45) NULL,
  `admission_date` VARCHAR(45) NULL,
  `parent_phone` VARCHAR(45) NULL,
  PRIMARY KEY (`stu_id`));
  insert into roommate select stu_id,bed_id,dept_name,grade,admission_date,parent_phone from student where room_build_id=b_id and room_id=r_id and stu_id<>s_id;
  select A.stu_id,B.name,A.dept_name,A.grade,B.birthday,B.own_phone,A.parent_phone,A.bed_id
  from (select * from information
  where information_id in
  (select information_id from student where stu_id in(select stu_id from roommate))) as B natural join roommate as A;
  drop table if exists roommate;
end;

