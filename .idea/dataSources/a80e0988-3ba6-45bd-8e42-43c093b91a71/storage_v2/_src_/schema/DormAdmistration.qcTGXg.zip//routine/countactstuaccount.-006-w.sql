create
    definer = db2019@`%` procedure countactstuaccount()
begin
select sum(act_capacity) from room;
end;

