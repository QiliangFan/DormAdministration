create
  definer = db2019@`%` procedure change_TeaInformation(IN account varchar(45), IN t_id int, IN n varchar(45),
                                                       IN g varchar(45), IN b_id varchar(45), IN phone varchar(45),
                                                       IN bir varchar(45))
begin
    declare flag int(1);
    if(select count(*) from manager)>0 then
        set flag=1;
    else
        set flag=0;
    end if;
    if flag=1 then
        update manager set m_id=t_id,manager.name=n,gender=g,build_id=b_id,own_phone=phone,birthday=bir where account_name=account;
    else
        insert into manager(m_id, build_id, name, own_phone, gender, birthday, account_name)
        values (t_id,b_id,n,phone,g,bir,account);
    end if;
end;

