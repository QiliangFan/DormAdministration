create
  definer = db2019@`%` procedure FindAvailableRoom(IN a_id varchar(45))
begin
declare ma_id int;
declare b_id int;
declare remainbeds int;
 if (select type from account where account_name=a_id)='manager' then
if(select m_id from manager where account_name=a_id)is not null then
create temporary table temtable(room_id int,RemainBeds int);
set b_id=(select build_id from manager where m_id=ma_id);
insert into temtable
	select room_id,RemainBeds(ma_id,room_id) from room where build_id=b_id and act_capacity<max_capacity;
select * from  temtable;
drop table if exists temtable;
end if;
end if;
end;

