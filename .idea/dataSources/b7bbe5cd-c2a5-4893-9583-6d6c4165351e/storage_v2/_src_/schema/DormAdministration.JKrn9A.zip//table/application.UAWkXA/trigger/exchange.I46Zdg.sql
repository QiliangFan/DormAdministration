create definer = db2019@`%` trigger exchange
  after INSERT
  on application
  for each row
BEGIN
  INSERT INTO log(s_id,s_name,b_id ,f_room_id ,t_room_id ,date) values(new.s_id,new.s_name,new.b_id,new.f_room_id,new.t_room_id,new.date);
END;

