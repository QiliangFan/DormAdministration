create
  definer = db2019@`%` procedure change_information(IN account varchar(45), IN s_id int, IN myname varchar(45),
                                                    IN d_name varchar(45), IN gra varchar(45), IN par_phone varchar(45),
                                                    IN myphone varchar(45), IN mygender varchar(45),
                                                    IN b_id varchar(45), IN ad_date varchar(45),
                                                    IN mybirthday varchar(45))
begin
declare flag int(10) default -1;
if(select count(*) from student where account_name=account)>0 then
set flag=1;#已经存在 直接覆盖
else
set flag=0;#没存在 插入
end if;
if flag=1 then
update student set bed_id=b_id,dept_name=d_name,grade=gra,admission_date=ad_date,parent_phone=par_phone,name=myname,own_phone=myphone,gender=mygender,birthday=mybirthday ,account_name=account where account_name=account;
else
insert into student (stu_id,bed_id,dept_name,grade,admission_date,parent_phone,name,own_phone,gender,birthday,account_name)values(s_id,b_id,d_name,gra,ad_date,par_phone,myname,myphone,mygender,mybirthday,account);
end  if;
end;

