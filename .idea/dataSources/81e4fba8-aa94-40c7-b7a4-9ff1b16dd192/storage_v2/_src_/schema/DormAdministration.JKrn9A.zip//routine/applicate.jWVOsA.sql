create
    definer = db2019@`%` procedure applicate(IN cur_s_id int, IN a_s_id int, IN a_s_name varchar(45), IN a_b_id int,
                                             IN a_f_room_id int, IN a_t_room_id int)
begin
declare cur_build_id int;
declare cur_room_id int;
select room_build_id,room_id into cur_build_id,cur_room_id from student where stu_id=cur_s_id;
select room_build_id,room_id from student where stu_id=cur_s_id;
if(cur_s_id=a_s_id and cur_build_id=a_b_id and cur_room_id=a_f_room_id)then
insert into application(s_id,s_name,b_id ,f_room_id ,t_room_id ,date) values(a_s_id, a_s_name, a_b_id , a_f_room_id , a_t_room_id,now());
end if;
end;

