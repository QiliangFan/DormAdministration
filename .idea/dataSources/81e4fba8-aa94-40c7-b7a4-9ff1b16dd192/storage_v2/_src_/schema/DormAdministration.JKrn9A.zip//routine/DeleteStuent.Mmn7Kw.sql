create
    definer = db2019@`%` procedure DeleteStuent(IN a_id varchar(45), IN s_id int)
    if (select type from account where account_name=a_id)='manager' then
if(select m_id from manager where account_name=a_id)is not null then


if (select room_build_id from student where stu_id=s_id) is not null then
	if (select room_build_id from student where stu_id=s_id)=(select build_id from manager where m_id=(select m_id from manager where account_name=a_id)) then
		if (select act_capacity from room where room_id=(select room_id from student where stu_id=s_id) and build_id=(select room_build_id from student where stu_id=s_id))=1 then
			update building set act_roomnum=act_roomnum+1 where build_id=(select room_build_id from student where stu_id=s_id);
		end if;
		update student set room_build_id=null where stu_id=s_id;
		update student set room_id=null where stu_id=s_id;
		update student set bed_id=null where stu_id=s_id;
		update room set act_capacity=act_capacity-1 where build_id=(select room_build_id from student where stu_id=s_id) and room_id=(select room_id from student where stu_id=s_id);
	end if;
end if;
end if;
end if;

