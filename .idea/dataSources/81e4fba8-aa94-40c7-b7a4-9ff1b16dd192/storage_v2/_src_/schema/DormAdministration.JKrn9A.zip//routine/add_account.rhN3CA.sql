create
    definer = db2019@`%` procedure add_account()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE j INT DEFAULT 3000;
    WHILE (i <= 1700) DO
        INSERT INTO account (`account_name` ,`password` ,`type` ) 
        VALUES (1000+i,1000+i,"student");
        SET i = i + 1;
    END WHILE;
    
     WHILE (j <= 3090) DO #男女各住了15栋楼 一个楼3个宿管
        INSERT INTO account (`account_name` ,`password` ,`type` ) 
        VALUES (j,j,"manager");
        SET j= j + 1;
    END WHILE;
END;

