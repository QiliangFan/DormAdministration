create
    definer = db2019@`%` procedure OneRoomRemainBeds(IN a_id varchar(45), IN r_id int)
begin
declare ma_id int;
declare b_id int;
if (select type from account where account_name=a_id)='manager' then
if(select m_id from manager where account_name=a_id)is not null then
set b_id=(select build_id from manager where m_id=ma_id);
select b_id,RemainBeds(ma_id,b_id);
end if;
end if;
end;

