create
    definer = db2019@`%` procedure add_room()
BEGIN
    declare b int DEFAULT 1;#楼号
    DECLARE i INT DEFAULT 1;#层数
	DECLARE j INT DEFAULT 1;#房间
    
    WHILE (b <= 40) DO
		WHILE (i <= 6) DO
			while(j<=20)DO
				INSERT INTO room (`room_id` ,`floor`,`max_capacity`,`build_id`) 
					VALUES (j+i*100,i,4,b);
				SET j = j + 1;
			END WHILE;
		SET i = i + 1;
		set j=1;
		END WHILE;
    SET b = b + 1;
    set i=1;
    set j=1;
    END WHILE;
END;

